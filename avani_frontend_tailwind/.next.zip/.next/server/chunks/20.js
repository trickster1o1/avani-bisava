"use strict";
exports.id = 20;
exports.ids = [20];
exports.modules = {

/***/ 9020:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BX": () => (/* binding */ savePaymentMethod),
/* harmony export */   "QR": () => (/* binding */ removeToCart),
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "q7": () => (/* binding */ saveShippingAddress)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1838);
/* harmony import */ var _constants_cartConstant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2562);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(551);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const addToCart = (id, qty)=>async (dispatch, getState)=>{
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/product/${id}`);
        dispatch({
            type: _constants_cartConstant__WEBPACK_IMPORTED_MODULE_4__/* .CART_ADD_ITEM */ .Nw,
            payload: {
                uuid: data.uuid,
                name: data.name,
                price: data.price,
                discount: data.price_discount,
                image: data.image,
                qty
            }
        });
        (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .setLocalStorage */ .qQ)("cartItems", getState().productAddToCart.cartItems);
    };
const removeToCart = (id)=>async (dispatch, getState)=>{
        dispatch({
            type: _constants_cartConstant__WEBPACK_IMPORTED_MODULE_4__/* .CART_REMOVE_ITEM */ .aR,
            payload: id
        });
        (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .setLocalStorage */ .qQ)("cartItems", getState().productAddToCart.cartItems);
    };
const saveShippingAddress = (shipping)=>async (dispatch)=>{
        dispatch({
            type: _constants_cartConstant__WEBPACK_IMPORTED_MODULE_4__/* .CART_SAVE_SHIPPING_ADDRESS */ .ko,
            payload: shipping
        });
        (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .setLocalStorage */ .qQ)("saveShippingAddress", shipping);
    };
const savePaymentMethod = (payment)=>async (dispatch)=>{
        dispatch({
            type: _constants_cartConstant__WEBPACK_IMPORTED_MODULE_4__/* .CART_SAVE_PAYMENT_METHOD */ .TU,
            payload: payment
        });
        (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .setLocalStorage */ .qQ)("savePaymentMethod", payment);
    };

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2562:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nw": () => (/* binding */ CART_ADD_ITEM),
/* harmony export */   "TU": () => (/* binding */ CART_SAVE_PAYMENT_METHOD),
/* harmony export */   "aR": () => (/* binding */ CART_REMOVE_ITEM),
/* harmony export */   "ko": () => (/* binding */ CART_SAVE_SHIPPING_ADDRESS)
/* harmony export */ });
const CART_ADD_ITEM = "CART_ADD_ITEM";
const CART_REMOVE_ITEM = "CART_REMOVE_ITEM";
const CART_SAVE_SHIPPING_ADDRESS = "CART_SAVE_SHIPPING_ADDRESS";
const CART_SAVE_PAYMENT_METHOD = "CART_SAVE_PAYMENT_METHOD";


/***/ })

};
;