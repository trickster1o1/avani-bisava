"use strict";
exports.id = 220;
exports.ids = [220];
exports.modules = {

/***/ 6220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ab": () => (/* binding */ ORDER_DETAILS_FAIL),
/* harmony export */   "E0": () => (/* binding */ ORDER_LIST_FAIL),
/* harmony export */   "MB": () => (/* binding */ ORDER_ADD_REQUEST),
/* harmony export */   "MM": () => (/* binding */ ORDER_ADD_SUCCESS),
/* harmony export */   "RQ": () => (/* binding */ ORDER_LIST_BY_USERID_REQUEST),
/* harmony export */   "Ut": () => (/* binding */ ORDER_ADD_RESET),
/* harmony export */   "YO": () => (/* binding */ ORDER_DETAILS_REQUEST),
/* harmony export */   "YY": () => (/* binding */ ORDER_ADD_FAIL),
/* harmony export */   "_4": () => (/* binding */ ORDER_UPDATE_TO_PAY_FAIL),
/* harmony export */   "bt": () => (/* binding */ ORDER_UPDATE_TO_PAY_REQUEST),
/* harmony export */   "cB": () => (/* binding */ ORDER_LIST_REQUEST),
/* harmony export */   "gV": () => (/* binding */ ORDER_UPDATE_TO_PAY_SUCCESS),
/* harmony export */   "um": () => (/* binding */ ORDER_DETAILS_SUCCESS),
/* harmony export */   "xg": () => (/* binding */ ORDER_LIST_BY_USERID_FAIL),
/* harmony export */   "yV": () => (/* binding */ ORDER_LIST_BY_USERID_SUCCESS),
/* harmony export */   "zL": () => (/* binding */ ORDER_LIST_SUCCESS)
/* harmony export */ });
/* unused harmony exports ORDER_UPDATE_TO_PAY_RESET, ORDER_UPDATE_TO_DELIVERED_REQUEST, ORDER_UPDATE_TO_DELIVERED_SUCCESS, ORDER_UPDATE_TO_DELIVERED_FAIL, ORDER_UPDATE_TO_DELIVERED_RESET, ORDER_DELETE_REQUEST, ORDER_DELETE_SUCCESS, ORDER_DELETE_FAIL */
const ORDER_LIST_REQUEST = "ORDER_LIST_REQUEST";
const ORDER_LIST_SUCCESS = "ORDER_LIST_SUCCESS";
const ORDER_LIST_FAIL = "ORDER_LIST_FAIL";
const ORDER_LIST_BY_USERID_REQUEST = "ORDER_LIST_BY_USERID_REQUEST";
const ORDER_LIST_BY_USERID_SUCCESS = "ORDER_LIST_BY_USERID_SUCCESS";
const ORDER_LIST_BY_USERID_FAIL = "ORDER_LIST_BY_USERID_FAIL";
const ORDER_ADD_REQUEST = "ORDER_ADD_REQUEST";
const ORDER_ADD_SUCCESS = "ORDER_ADD_SUCCESS";
const ORDER_ADD_FAIL = "ORDER_ADD_FAIL";
const ORDER_ADD_RESET = "ORDER_ADD_RESET";
const ORDER_DETAILS_REQUEST = "ORDER_DETAILS_REQUEST";
const ORDER_DETAILS_SUCCESS = "ORDER_DETAILS_SUCCESS";
const ORDER_DETAILS_FAIL = "ORDER_DETAILS_FAIL";
const ORDER_UPDATE_TO_PAY_REQUEST = "ORDER_UPDATE_TO_PAY_REQUEST";
const ORDER_UPDATE_TO_PAY_SUCCESS = "ORDER_UPDATE_TO_PAY_SUCCESS";
const ORDER_UPDATE_TO_PAY_FAIL = "ORDER_UPDATE_TO_PAY_FAIL";
const ORDER_UPDATE_TO_PAY_RESET = "ORDER_UPDATE_TO_PAY_RESET";
const ORDER_UPDATE_TO_DELIVERED_REQUEST = "ORDER_UPDATE_TO_DELIVERED_REQUEST";
const ORDER_UPDATE_TO_DELIVERED_SUCCESS = "ORDER_UPDATE_TO_DELIVERED_SUCCESS";
const ORDER_UPDATE_TO_DELIVERED_FAIL = "ORDER_UPDATE_TO_DELIVERED_FAIL";
const ORDER_UPDATE_TO_DELIVERED_RESET = "ORDER_UPDATE_TO_DELIVERED_RESET";
const ORDER_DELETE_REQUEST = "ORDER_DELETE_REQUEST";
const ORDER_DELETE_SUCCESS = "ORDER_DELETE_SUCCESS";
const ORDER_DELETE_FAIL = "ORDER_DELETE_FAIL";


/***/ })

};
;