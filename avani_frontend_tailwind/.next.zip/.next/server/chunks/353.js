"use strict";
exports.id = 353;
exports.ids = [353];
exports.modules = {

/***/ 7353:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ag": () => (/* binding */ getBlogsByUserId),
/* harmony export */   "Vh": () => (/* binding */ createBlog),
/* harmony export */   "X4": () => (/* binding */ deleteBlog),
/* harmony export */   "zZ": () => (/* binding */ updateBlog)
/* harmony export */ });
/* unused harmony exports getBlogs, getBlog */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1838);
/* harmony import */ var _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5047);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(551);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const getBlogs = ()=>async (dispatch)=>{
        try {
            dispatch({
                type: BLOG_LIST_REQUEST
            });
            const config = {
                headers: {
                    "Content-Type": "application/json"
                }
            };
            const { data  } = await axios.get(`${API}/blog`, config);
            dispatch({
                type: BLOG_LIST_SUCCESS,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: BLOG_LIST_FAIL,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const getBlogsByUserId = (uuid)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_LIST_BY_USERID_REQUEST */ .j0
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/blog/user/${uuid}`, config);
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_LIST_BY_USERID_SUCCESS */ .xz,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_LIST_BY_USERID_FAIL */ .lI,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const getBlog = (uuid)=>async (dispatch)=>{
        try {
            dispatch({
                type: BLOG_DETAILS_REQUEST
            });
            const config = {
                headers: {
                    "Content-Type": "application/json"
                }
            };
            const { data  } = await axios.get(`${API}/blog/${uuid}`, config);
            dispatch({
                type: BLOG_DETAILS_SUCCESS,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: BLOG_DETAILS_FAIL,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const createBlog = (slug, title, image, description, userId)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_ADD_REQUEST */ .CG
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/blog`, {
                slug,
                title,
                image,
                description,
                userId
            }, config);
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_ADD_SUCCESS */ .EL,
                payload: data
            });
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_ADD_FAIL */ .DJ,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const updateBlog = (slug, title, image, description, uuid)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_UPDATE_REQUEST */ .tj
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/blog/${uuid}`, {
                slug,
                title,
                image,
                description
            }, config);
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_UPDATE_SUCCESS */ .cW,
                payload: data
            });
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_UPDATE_FAIL */ .MY,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const deleteBlog = (uuid, userId)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_DELETE_REQUEST */ .gL
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/blog/${uuid}/${userId}`, config);
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_DELETE_SUCCESS */ .Ke,
                payload: data
            });
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_blogConstant__WEBPACK_IMPORTED_MODULE_4__/* .BLOG_DELETE_FAIL */ .M7,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;