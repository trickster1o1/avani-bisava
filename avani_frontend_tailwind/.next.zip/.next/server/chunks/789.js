"use strict";
exports.id = 789;
exports.ids = [789];
exports.modules = {

/***/ 8200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avani_logo.3f4c62aa.jpg","height":150,"width":150,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAK6If//EABoQAQABBQAAAAAAAAAAAAAAAAECAAMSQWH/2gAIAQEAAT8AC5PFQikhXbyv/8QAFREBAQAAAAAAAAAAAAAAAAAAAQD/2gAIAQIBAT8AC//EABURAQEAAAAAAAAAAAAAAAAAAAAB/9oACAEDAQE/AK//2Q==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3736:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports setLocalStorage, removeLocalStorage, addToCart, removeCartItem, getCartItemsFromLocalStorage */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__]);
react_toastify__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


let cartItemsFromStorage = (/* unused pure expression or super */ null && ( false ? 0 : []));
// localstorage
const setLocalStorage = (key, value)=>{
    if (false) {}
};
// remove localstorge
const removeLocalStorage = (key)=>{
    if (false) {}
};
// add to cart
const addToCart = async (id, qty)=>{
    const { data  } = await axios.get(`http://localhost:5000/api/product/${id}`);
    const product = {
        uuid: data.uuid,
        name: data.name,
        price: data.price,
        discount: data.price_discount,
        image: data.image,
        qty
    };
    const exitItem = cartItemsFromStorage.find((x)=>x.uuid === product.uuid);
    if (exitItem) {
        cartItemsFromStorage = cartItemsFromStorage.map((x)=>x.uuid === exitItem.uuid ? product : x);
        toast.info("Product Already Added To Cart", {
            autoClose: 1000
        });
    } else {
        cartItemsFromStorage.push(product);
        toast.info("Product Added To Cart", {
            autoClose: 1000
        });
    }
    setLocalStorage("cartItems", cartItemsFromStorage);
// console.log("cartItemsFromStorage", cartItemsFromStorage);
};
// remove items from cart
const removeCartItem = (uuid)=>{
    const cartItemsAfterRemove = cartItemsFromStorage.filter((x)=>x.uuid !== uuid);
    toast.error("Product Remove from Cart", {
        autoClose: 1000
    });
    // console.log("cartItemsAfterRemove", cartItemsAfterRemove);
    setLocalStorage("cartItems", cartItemsAfterRemove);
// localStorage.setItem("cartItems", JSON.stringify(cartItemsAfterRemove));
};
const getCartItemsFromLocalStorage = ()=>{
    if (false) {}
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Container = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "max-w-7xl mx-auto px-10 sm:px-6 lg:px-14 border-gray-200 py-2.5 rounded ",
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ }),

/***/ 3193:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2369);
/* harmony import */ var _data_categoryData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8277);
/* harmony import */ var _public_avani_logo_jpg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8200);






const Footer = ()=>{
    console.log("categoryData", categoryData);
    return /*#__PURE__*/ _jsx("div", {
        className: "bg-primary mt-5",
        children: /*#__PURE__*/ _jsx(Container, {
            children: /*#__PURE__*/ _jsxs("div", {
                className: "grid grid-cols-2 lg:grid-cols-12 gap-10 text-white py-8",
                children: [
                    /*#__PURE__*/ _jsxs("div", {
                        className: "md:col-span-5",
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "log",
                                children: /*#__PURE__*/ _jsx(Link, {
                                    href: "/",
                                    children: /*#__PURE__*/ _jsxs("a", {
                                        className: "flex justify-center items-center",
                                        children: [
                                            /*#__PURE__*/ _jsx(Image, {
                                                src: logo,
                                                alt: "Picture of the author",
                                                width: 50,
                                                height: 50
                                            }),
                                            /*#__PURE__*/ _jsx("h1", {
                                                className: "text-lg md:text-2xl font-semibold ml-2",
                                                children: APP_NAME
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ _jsx("h1", {
                                className: "text-xl uppercase font-bold mb-5",
                                children: "Avani Nepal"
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                children: /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga velit totam unde molestias officiis repellat",
                                        " ",
                                        /*#__PURE__*/ _jsx(Link, {
                                            href: "/",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white underline",
                                                children: "Read More ..."
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "md:col-span-2",
                        children: [
                            /*#__PURE__*/ _jsx("h1", {
                                className: "text-xl uppercase font-bold mb-5",
                                children: "Shop"
                            }),
                            /*#__PURE__*/ _jsx("ul", {
                                children: categoryData.map((value)=>/*#__PURE__*/ _jsx("li", {
                                        className: "pb-3",
                                        children: /*#__PURE__*/ _jsx(Link, {
                                            href: "/",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white capitalize",
                                                children: value.categoryName
                                            })
                                        })
                                    }))
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "md:col-span-2",
                        children: [
                            /*#__PURE__*/ _jsx("h1", {
                                className: "text-xl uppercase font-bold mb-5",
                                children: "Help"
                            }),
                            /*#__PURE__*/ _jsxs("ul", {
                                children: [
                                    /*#__PURE__*/ _jsx("li", {
                                        className: "pb-3",
                                        children: /*#__PURE__*/ _jsx(Link, {
                                            href: "/about-us",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white",
                                                children: "About Us"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("li", {
                                        className: "pb-3",
                                        children: /*#__PURE__*/ _jsx(Link, {
                                            href: "/contact-us",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white",
                                                children: "Contact Us"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("li", {
                                        className: "pb-3",
                                        children: /*#__PURE__*/ _jsx(Link, {
                                            href: "/privacy-policy",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white",
                                                children: "Privacy Policy"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("li", {
                                        className: "pb-3",
                                        children: /*#__PURE__*/ _jsx(Link, {
                                            href: "/refund-policy",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white",
                                                children: "Refund Policy"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("li", {
                                        className: "pb-3",
                                        children: /*#__PURE__*/ _jsx(Link, {
                                            href: "/shipping-policy",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white",
                                                children: "Shipping Policy"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("li", {
                                        children: /*#__PURE__*/ _jsx(Link, {
                                            href: "/terms-of-service",
                                            children: /*#__PURE__*/ _jsx("a", {
                                                className: "text-white",
                                                children: "Terms Of Service"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "md:col-span-3",
                        children: [
                            /*#__PURE__*/ _jsx("h1", {
                                className: "text-xl uppercase font-bold mb-5",
                                children: "Stay Updated"
                            }),
                            /*#__PURE__*/ _jsxs("div", {
                                className: "flex",
                                children: [
                                    /*#__PURE__*/ _jsx(Link, {
                                        href: "/",
                                        children: /*#__PURE__*/ _jsx("a", {
                                            className: "text-3xl text-white",
                                            children: /*#__PURE__*/ _jsx("i", {
                                                class: "fa-brands fa-facebook "
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx(Link, {
                                        href: "/",
                                        children: /*#__PURE__*/ _jsx("a", {
                                            className: "text-3xl text-white ml-5",
                                            children: /*#__PURE__*/ _jsx("i", {
                                                class: "fa-brands fa-instagram"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Footer)));


/***/ }),

/***/ 7673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2369);
/* harmony import */ var _data_categoryData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8277);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);







const Header = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
            className: "hidden md:block m-auto border-t border-primary border-b",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: "flex flex-col mt-4 md:flex-row md:mt-0 md:text-sm md:font-medium justify-center relative ",
                children: [
                    _data_categoryData__WEBPACK_IMPORTED_MODULE_4__/* .categoryData.map */ .e.map((value, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: "hover:bg-gray-100 mega_menu_link",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "#",
                                    className: "block text-white py-3 px-4 bg-primary rounded md:bg-transparent md:text-primaryDark dark:text-white uppercase",
                                    "aria-current": "page",
                                    children: value.categoryName
                                }),
                                value.subCategory.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mega_menu border-t border-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-14 bg-white flex space-x-16",
                                        children: value.subCategory.map((value, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "mb-2 text-lg uppercase font-[400]",
                                                        children: value.subCategoryName
                                                    }),
                                                    value.childCategory.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: "my-2 text-base font-[100]",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                href: `/products?search=&sort=&category=${value.value}`,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    className: "uppercase",
                                                                    children: value.childCategoryName
                                                                })
                                                            })
                                                        }, "l" + index))
                                                ]
                                            }, "sb" + index))
                                    })
                                })
                            ]
                        }, "m" + index)),
                    _data_categoryData__WEBPACK_IMPORTED_MODULE_4__/* .singleCategoryData.map */ .y.map((value, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: "hover:bg-gray-100 single_mega_menu_link",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "#",
                                    className: "block text-white py-3 px-4 bg-primary rounded md:bg-transparent md:text-primaryDark dark:text-white uppercase",
                                    "aria-current": "page",
                                    children: value.categoryName
                                }),
                                value.subCategory.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "single_mega_menu border-t border-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "max-w-7xl mx-auto px-4 py-2 sm:px-6 lg:px-7 bg-white flex space-x-16",
                                        children: value.subCategory.map((value, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "mb-2 text-lg uppercase",
                                                        children: value.subCategoryName
                                                    }),
                                                    value.childCategory.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: "my-2 text-base",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                href: `/products?search=&sort=&category=${value.value}`,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    className: "uppercase font-[100]",
                                                                    children: value.childCategoryName
                                                                })
                                                            })
                                                        }, "c" + index))
                                                ]
                                            }, "s" + index))
                                    })
                                })
                            ]
                        }, "s" + index)),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            href: "/products?search=&sort=&category=",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "block text-white py-3 px-4 bg-primary rounded md:bg-transparent md:text-primaryDark dark:text-white uppercase",
                                "aria-current": "page",
                                children: "All Products"
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);


/***/ }),

/***/ 5789:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2369);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3193);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7673);
/* harmony import */ var _TopHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(922);
/* harmony import */ var _data_categoryData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8277);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1838);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TopHeader__WEBPACK_IMPORTED_MODULE_5__]);
_TopHeader__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const Layout = ({ children , header =true , footer =true , aboutUsData  })=>{
    console.log("object", _data_categoryData__WEBPACK_IMPORTED_MODULE_6__/* .categoryData */ .e);
    let categoryDataValue = [];
    // footer text color===============
    const customColor = "[#6b8874]";
    // const customColor = 'white';
    // footer background===============
    // const bgTheme = '[#edfae9]';
    // const bgTheme = 'primary';
    const bgTheme = "[white]";
    // ================================
    for(let i = 0; i < _data_categoryData__WEBPACK_IMPORTED_MODULE_6__/* .categoryData.length */ .e.length; i++){
        // categoryDataValue.push(categoryData[i].categoryName);
        for(let j = 0; j < _data_categoryData__WEBPACK_IMPORTED_MODULE_6__/* .categoryData */ .e[i].subCategory.length; j++){
            // categoryDataValue.push(categoryData[i].subCategory[j].subCategoryName);
            for(let k = 0; k < _data_categoryData__WEBPACK_IMPORTED_MODULE_6__/* .categoryData */ .e[i].subCategory[j].childCategory.length; k++){
                let categoryObject = {};
                categoryObject.title = _data_categoryData__WEBPACK_IMPORTED_MODULE_6__/* .categoryData */ .e[i].subCategory[j].childCategory[k].childCategoryName;
                categoryObject.value = _data_categoryData__WEBPACK_IMPORTED_MODULE_6__/* .categoryData */ .e[i].subCategory[j].childCategory[k].value;
                categoryDataValue.push(categoryObject);
            // categoryDataValue.push(
            //   categoryData[i].subCategory[j].childCategory[k].childCategoryName,
            //   categoryData[i].subCategory[j].childCategory[k].value
            // );
            }
        }
    }
    console.log("categoryDataValue", categoryDataValue);
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July", 
    ];
    const random = Math.floor(Math.random() * categoryDataValue.length);
    console.log(Math.floor(Math.random() * categoryDataValue.length), categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)]);
    console.log(Math.floor(Math.random() * categoryDataValue.length), categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)]);
    console.log(Math.floor(Math.random() * categoryDataValue.length), categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)]);
    const cat1 = categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)];
    const cat2 = categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)];
    const cat3 = categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)];
    const cat4 = categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)];
    const cat5 = categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)];
    const cat6 = categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)];
    const cat7 = categoryDataValue[Math.floor(Math.random() * categoryDataValue.length)];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TopHeader__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                    !header && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-primary border-b"
                    })
                ]
            }),
            header && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            children,
            footer && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-" + bgTheme + " border border-t-primary",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-2 lg:grid-cols-12 gap-10 py-8 text-" + customColor,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:col-span-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "log mb-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                className: "flex items-center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                        src: "/avani_logo.jpg",
                                                        alt: "Picture of the author",
                                                        width: 50,
                                                        height: 50,
                                                        className: "rounded-full"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                        className: "text-xl uppercase font-bold  ml-2 text-" + customColor,
                                                        children: _config__WEBPACK_IMPORTED_MODULE_8__/* .APP_NAME */ .iC
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            aboutUsData.description.length > 250 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                dangerouslySetInnerHTML: {
                                                    __html: aboutUsData.description.split(" ").slice(0, 20).join(" ") + "..."
                                                }
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                dangerouslySetInnerHTML: {
                                                    __html: aboutUsData.description
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                href: "/about-us",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "underline text-" + customColor,
                                                    children: "Read More ..."
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:col-span-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-xl uppercase font-bold mb-5",
                                        children: "Shop"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/products?search=&sort=&category=${cat1.value}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "capitalize text-" + customColor,
                                                        children: cat1.title
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/products?search=&sort=&category=${cat2.value}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "capitalize text-" + customColor,
                                                        children: cat2.title
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/products?search=&sort=&category=${cat3.value}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "capitalize text-" + customColor,
                                                        children: cat3.title
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/products?search=&sort=&category=${cat4.value}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "capitalize text-" + customColor,
                                                        children: cat4.title
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/products?search=&sort=&category=${cat5.value}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "capitalize text-" + customColor,
                                                        children: cat5.title
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/products?search=&sort=&category=${cat6.value}`,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "capitalize text-" + customColor,
                                                        children: cat6.title
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:col-span-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-xl uppercase font-bold mb-5",
                                        children: "Help"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: "/about-us",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-" + customColor,
                                                        children: "About Us"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: "/contact-us",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-" + customColor,
                                                        children: "Contact Us"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: "/privacy-policy",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-" + customColor,
                                                        children: "Privacy Policy"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: "/refund-policy",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-" + customColor,
                                                        children: "Refund Policy"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "pb-3",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: "/shipping-policy",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-" + customColor,
                                                        children: "Shipping Policy"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: "/terms-of-service",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "text-" + customColor,
                                                        children: "Terms Of Service"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:col-span-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-xl uppercase font-bold mb-5",
                                        children: "Stay Updated"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                href: "/",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "text-3xl text-" + customColor,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-brands fa-facebook "
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                href: "/",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "text-3xl ml-5 text-" + customColor,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-brands fa-instagram"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 922:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2369);
/* harmony import */ var _public_avani_logo_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8200);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1838);
/* harmony import */ var _actions_cart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3736);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _redux_actions_userAction__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7867);
/* harmony import */ var _redux_utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(551);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1185);
/* harmony import */ var _data_categoryData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8277);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_actions_cart__WEBPACK_IMPORTED_MODULE_8__, _redux_actions_userAction__WEBPACK_IMPORTED_MODULE_10__, _redux_utils__WEBPACK_IMPORTED_MODULE_11__, _headlessui_react__WEBPACK_IMPORTED_MODULE_13__]);
([_actions_cart__WEBPACK_IMPORTED_MODULE_8__, _redux_actions_userAction__WEBPACK_IMPORTED_MODULE_10__, _redux_utils__WEBPACK_IMPORTED_MODULE_11__, _headlessui_react__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const TopHeader = ()=>{
    const Router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    console.log("isAtuh", (0,_redux_utils__WEBPACK_IMPORTED_MODULE_11__/* .isAuth */ .$D)());
    const { 0: toggleMenu , 1: setToggleMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: openDrawer , 1: setOpenDrawer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: openSubCategory , 1: setOpenSubCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: openChildCategory , 1: setOpenChildCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: openSingleChildCategory , 1: setOpenSingleChildCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: searchTag , 1: setSearchTag  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useDispatch)();
    const productAddToCart = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useSelector)((state)=>state.productAddToCart);
    const { cartItems  } = productAddToCart;
    console.log("categoryData", _data_categoryData__WEBPACK_IMPORTED_MODULE_14__/* .categoryData */ .e);
    console.log("singleCategoryData", _data_categoryData__WEBPACK_IMPORTED_MODULE_14__/* .singleCategoryData */ .y);
    const handleSearchBtn = (e)=>{
        e.preventDefault();
        console.log("object", searchTag);
        Router.push(`/products?search=${searchTag}&sort=&category=`);
        setSearchTag("");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "md:flex md:justify-between items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "log",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: "/",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: "flex justify-center items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            src: _public_avani_logo_jpg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                                            alt: "Picture of the author",
                                            width: 50,
                                            height: 50
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "text-lg md:text-2xl font-semibold ml-2",
                                            children: _config__WEBPACK_IMPORTED_MODULE_7__/* .APP_NAME */ .iC
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "block md:hidden",
                                    onClick: ()=>setOpenDrawer(!openDrawer),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        strokeWidth: "1.5",
                                        stroke: "currentColor",
                                        className: "w-6 h-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            d: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "border-r",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "https://m.facebook.com/profile.php?id=100064108204945&eav=Afbwf2xBx_S1s72sRgG_ODvDXolufNgdrZ8oRodsswDi1XL0jTAovGMACrcgeHq02hM&paipv=0&_rdr",
                                                    className: "",
                                                    target: "_blank",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-brands fa-facebook text-2xl"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "https://www.instagram.com/avaninepal/?hl=en",
                                                    className: "mx-4",
                                                    target: "_blank",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa-brands fa-instagram text-2xl"
                                                    })
                                                })
                                            ]
                                        }),
                                        !(0,_redux_utils__WEBPACK_IMPORTED_MODULE_11__/* .isAuth */ .$D)() && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                href: "/signin",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "mx-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        className: "h-6 w-6",
                                                        fill: "none",
                                                        viewBox: "0 0 24 24",
                                                        stroke: "currentColor",
                                                        strokeWidth: 2,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                                                        })
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: "/cart",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: " flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            className: "h-6 w-6",
                                                            fill: "none",
                                                            viewBox: "0 0 24 24",
                                                            stroke: "currentColor",
                                                            strokeWidth: 2,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                d: "M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "ml-1 text-sm font-medium text-gray-700 group-hover:text-gray-800",
                                                            children: cartItems && cartItems.length
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: (0,_redux_utils__WEBPACK_IMPORTED_MODULE_11__/* .isAuth */ .$D)() && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_13__.Menu, {
                                                    as: "div",
                                                    className: "relative inline-block text-left",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_13__.Menu.Button, {
                                                                className: "inline-flex w-full justify-center rounded-md text-black bg-opacity-20 px-4 py-2 text-sm font-medium hover:bg-opacity-30 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75",
                                                                children: [
                                                                    (0,_redux_utils__WEBPACK_IMPORTED_MODULE_11__/* .isAuth */ .$D)().name,
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        className: "ml-2 -mr-1 h-5 w-5 text-gray-400 hover:text-gray-600",
                                                                        fill: "none",
                                                                        viewBox: "0 0 24 24",
                                                                        stroke: "currentColor",
                                                                        strokeWidth: 2,
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                            strokeLinecap: "round",
                                                                            strokeLinejoin: "round",
                                                                            d: "M19 9l-7 7-7-7"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_13__.Transition, {
                                                            as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                                                            enter: "transition ease-out duration-100",
                                                            enterFrom: "transform opacity-0 scale-95",
                                                            enterTo: "transform opacity-100 scale-100",
                                                            leave: "transition ease-in duration-75",
                                                            leaveFrom: "transform opacity-100 scale-100",
                                                            leaveTo: "transform opacity-0 scale-95",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_13__.Menu.Items, {
                                                                className: "absolute right-0 mt-2 w-40 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-50",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                                    className: "px-1 py-1",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                href: "/profile",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                    onClick: ()=>setToggleMenu(false),
                                                                                    className: "cursor-pointer block py-2 px-4 hover:bg-gray-100 rounded-md",
                                                                                    children: "Profile"
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                onClick: ()=>dispatch((0,_redux_actions_userAction__WEBPACK_IMPORTED_MODULE_10__/* .logout */ .kS)(), setToggleMenu(false)),
                                                                                className: "block py-2 px-4 text-gray-700 hover:bg-gray-100 cursor-pointer rounded-md",
                                                                                children: "Sign out"
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            openDrawer && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "block md:hidden absolute z-[1000] h-[90vh] p-4 overflow-scroll bg-white w-80",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        className: "inline-flex items-center mb-2 text-lg font-semibold",
                        children: "Category"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        type: "button",
                        "data-drawer-dismiss": "drawer-example",
                        "aria-controls": "drawer-example",
                        className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 absolute top-2.5 right-2.5 inline-flex items-center",
                        onClick: ()=>setOpenDrawer(false),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                "aria-hidden": "true",
                                className: "w-5 h-5",
                                fill: "currentColor",
                                viewBox: "0 0 20 20",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    "fill-rule": "evenodd",
                                    d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                    "clip-rule": "evenodd"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "sr-only",
                                children: "Close menu"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            children: [
                                _data_categoryData__WEBPACK_IMPORTED_MODULE_14__/* .categoryData.map */ .e.map((value, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "my-1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-between",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                        className: "text-xl",
                                                        children: value.categoryName
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: openSubCategory === i ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            onClick: ()=>setOpenSubCategory(false),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                strokeWidth: "1.5",
                                                                stroke: "currentColor",
                                                                className: "w-6 h-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    d: "M18 12H6"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            onClick: ()=>setOpenSubCategory(i),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                strokeWidth: "1.5",
                                                                stroke: "currentColor",
                                                                className: "w-6 h-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    d: "M12 6v12m6-6H6"
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            openSubCategory === i && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "ml-5 my-3",
                                                children: value.subCategory.map((value1, j)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                                        className: "text-lg",
                                                                        children: value1.subCategoryName
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        children: openChildCategory === j ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            onClick: ()=>setOpenChildCategory(false),
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                                fill: "none",
                                                                                viewBox: "0 0 24 24",
                                                                                strokeWidth: "1.5",
                                                                                stroke: "currentColor",
                                                                                className: "w-6 h-6",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                    strokeLinecap: "round",
                                                                                    strokeLinejoin: "round",
                                                                                    d: "M18 12H6"
                                                                                })
                                                                            })
                                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            onClick: ()=>setOpenChildCategory(j),
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                                fill: "none",
                                                                                viewBox: "0 0 24 24",
                                                                                strokeWidth: "1.5",
                                                                                stroke: "currentColor",
                                                                                className: "w-6 h-6",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                                    strokeLinecap: "round",
                                                                                    strokeLinejoin: "round",
                                                                                    d: "M12 6v12m6-6H6"
                                                                                })
                                                                            })
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            openChildCategory === j && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                                className: "ml-5 my-3",
                                                                children: value1.childCategory.map((value2)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                            href: `/products?search=&sort=&category=${value2.value}`,
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                className: "text-lg",
                                                                                children: value2.childCategoryName
                                                                            })
                                                                        })
                                                                    }))
                                                            })
                                                        ]
                                                    }))
                                            })
                                        ]
                                    })),
                                _data_categoryData__WEBPACK_IMPORTED_MODULE_14__/* .singleCategoryData.map */ .y.map((value, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "my-1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-between",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                        className: "text-xl",
                                                        children: value.categoryName
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: openSingleChildCategory === i ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            onClick: ()=>setOpenSingleChildCategory(false),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                strokeWidth: "1.5",
                                                                stroke: "currentColor",
                                                                className: "w-6 h-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    d: "M18 12H6"
                                                                })
                                                            })
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            onClick: ()=>setOpenSingleChildCategory(i),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                strokeWidth: "1.5",
                                                                stroke: "currentColor",
                                                                className: "w-6 h-6",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    d: "M12 6v12m6-6H6"
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            openSingleChildCategory === i && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "ml-5 my-3",
                                                children: value.subCategory[0].childCategory.map((value1, j)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            href: `/products?search=&sort=&category=${value1.value}`,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                className: "text-lg",
                                                                children: value1.childCategoryName
                                                            })
                                                        })
                                                    }))
                                            })
                                        ]
                                    }))
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopHeader);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FH": () => (/* binding */ baseUrl),
/* harmony export */   "bl": () => (/* binding */ API),
/* harmony export */   "iC": () => (/* binding */ APP_NAME)
/* harmony export */ });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4558);
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);

const { publicRuntimeConfig  } = next_config__WEBPACK_IMPORTED_MODULE_0___default()();
const API = publicRuntimeConfig.PRODUCTION ? publicRuntimeConfig.API_PRODUCTION : publicRuntimeConfig.API_DEVELOPMENT;
const baseUrl = publicRuntimeConfig.PRODUCTION ? publicRuntimeConfig.BASE_URL_PRODUCTION : publicRuntimeConfig.BASE_URL_DEVELOPMENT;
const APP_NAME = publicRuntimeConfig.APP_NAME;


/***/ }),

/***/ 8277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ categoryData),
/* harmony export */   "y": () => (/* binding */ singleCategoryData)
/* harmony export */ });
const categoryData = [
    {
        categoryName: "skin",
        subCategory: [
            {
                subCategoryName: "shop by category",
                value: "shop_by_category",
                childCategory: [
                    {
                        childCategoryName: "cleansers",
                        value: "cleansers"
                    },
                    {
                        childCategoryName: "toners",
                        value: "toners"
                    },
                    // {
                    //   childCategoryName: "exfoliants",
                    //   value: "exfoliants",
                    // },
                    {
                        childCategoryName: "daily moisturisers",
                        value: "daily_moisturisers"
                    },
                    // {
                    //   childCategoryName: "mud masks",
                    //   value: "mud_masks",
                    // },
                    {
                        childCategoryName: "powder packs",
                        value: "powder_packs"
                    },
                    {
                        childCategoryName: "sun protection",
                        value: "sun_protection"
                    },
                    {
                        childCategoryName: "night creams & gels",
                        value: "night_creams & gels"
                    },
                    {
                        childCategoryName: "lip care",
                        value: "lip_care"
                    }, 
                ]
            },
            {
                subCategoryName: "shop by Concerns",
                value: "shop_by_Concerns",
                childCategory: [
                    {
                        childCategoryName: "blemishes",
                        value: "blemishes"
                    },
                    {
                        childCategoryName: "pimples / acne",
                        value: "pimples_acne"
                    },
                    {
                        childCategoryName: "anti-tan",
                        value: "anti_tan"
                    },
                    {
                        childCategoryName: "anti-ageing",
                        value: "anti_ageing"
                    },
                    {
                        childCategoryName: "under eye dark circle",
                        value: "under_eye_dark_circle"
                    },
                    {
                        childCategoryName: "glow boosters",
                        value: "glow_boosters"
                    },
                    {
                        childCategoryName: "pore refining",
                        value: "pore_refining"
                    },
                    {
                        childCategoryName: "sun protection",
                        value: "sun_protection"
                    }, 
                ]
            },
            {
                subCategoryName: "shop by skin type",
                value: "shop_by_skin_type",
                childCategory: [
                    {
                        childCategoryName: "dry to normal skin",
                        value: "dry_to_normal_skin"
                    },
                    {
                        childCategoryName: "oily/combination skin",
                        value: "oily/combination_skin"
                    },
                    {
                        childCategoryName: "acne-prone skin",
                        value: "acne-prone_skin"
                    },
                    {
                        childCategoryName: "view all skin care products",
                        value: "view_all_skin_care_products"
                    }, 
                ]
            },
            {
                subCategoryName: "shop by range",
                value: "shop_by_range",
                childCategory: [
                    // {
                    //   childCategoryName: "plant based retinol",
                    //   value: "plant_based_retinol",
                    // },
                    {
                        childCategoryName: "vitamin c skin brightening ramge",
                        value: "vitamin_c_skin_brightening_ramge"
                    }, 
                ]
            }, 
        ]
    },
    {
        categoryName: "hair",
        subCategory: [
            {
                subCategoryName: "shop by category",
                value: "shop_by_category",
                childCategory: [
                    // {
                    //   childCategoryName: "hair mask",
                    //   value: "hair_mask",
                    // },
                    {
                        childCategoryName: "hai oils",
                        value: "hai_oils"
                    }, 
                ]
            },
            {
                subCategoryName: "shop by concerns",
                value: "shop_by_concerns",
                childCategory: [
                    {
                        childCategoryName: "dandruff",
                        value: "dandruff"
                    },
                    {
                        childCategoryName: "volume",
                        value: "volume"
                    },
                    {
                        childCategoryName: "hair fall",
                        value: "hair_fall"
                    },
                    {
                        childCategoryName: "dry brittle hair",
                        value: "dry_brittle_hair"
                    }, 
                ]
            },
            {
                subCategoryName: "shop by hair type",
                value: "shop_by_hair_type",
                childCategory: [
                    {
                        childCategoryName: "normal to oily scalp",
                        value: "normal_to_oily_scalp"
                    },
                    {
                        childCategoryName: "dry to normal scalp",
                        value: "dry_to_normal_scalp"
                    },
                    {
                        childCategoryName: "view all hair care product",
                        value: "view_all_hair_care_product"
                    }, 
                ]
            },
            {
                subCategoryName: "shop by range",
                value: "shop_by_range",
                childCategory: [
                    {
                        childCategoryName: "castor & black onion seed range",
                        value: "castor & black_onion_seed_range"
                    }, 
                ]
            }, 
        ]
    }, 
];
const singleCategoryData = [
    {
        categoryName: "Bath & Care",
        subCategory: [
            {
                childCategory: [
                    // {
                    //   childCategoryName: "Body Scrub",
                    //   value: "body_scrub",
                    // },
                    // {
                    //   childCategoryName: "Body Butters",
                    //   value: "body_butters",
                    // },
                    {
                        childCategoryName: "Body oil",
                        value: "body_oil"
                    },
                    // {
                    //   childCategoryName: "Body wash",
                    //   value: "body_wash",
                    // },
                    {
                        childCategoryName: "Body lotion",
                        value: "body_lotion"
                    }, 
                ]
            }, 
        ]
    },
    // {
    //   categoryName: "Natural Makup",
    //   subCategory: [
    //     {
    //       childCategory: [
    //         {
    //           childCategoryName: "LIPS",
    //           value: "lips",
    //         },
    //         {
    //           childCategoryName: "FACE",
    //           value: "face",
    //         },
    //         {
    //           childCategoryName: "EYE",
    //           value: "eye",
    //         },
    //       ],
    //     },
    //   ],
    // },
    {
        categoryName: "Gifting",
        subCategory: [
            {
                childCategory: [
                    {
                        childCategoryName: "Gift Box",
                        value: "gift_box"
                    },
                    {
                        childCategoryName: "Gifts For Him",
                        value: "gifts_for_him"
                    },
                    {
                        childCategoryName: "Gifts For Her",
                        value: "gifts_for_her"
                    },
                    {
                        childCategoryName: "Co-operative Gifting",
                        value: "cooperative_gifting"
                    }, 
                ]
            }, 
        ]
    }, 
];


/***/ }),

/***/ 7867:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DZ": () => (/* binding */ userUpdate),
/* harmony export */   "N$": () => (/* binding */ userRegister),
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "n$": () => (/* binding */ userLogin)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1838);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7526);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(551);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_3__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const userLogin = (email, password)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_LOGIN_REQUEST */ .mA
            });
            const config = {
                headers: {
                    "Content-Type": "application/json"
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${_config__WEBPACK_IMPORTED_MODULE_0__/* .API */ .bl}/user/login`, {
                email,
                password
            }, config);
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.info("Login Successfully", {
                autoClose: 700
            });
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_LOGIN_SUCCESS */ .wW,
                payload: data
            });
            let userData = {
                id: data.id,
                uuid: data.uuid,
                name: data.name,
                email: data.email,
                phone: data.phone
            };
            (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .setCookies */ .lE)("token", data.token);
            (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .setLocalStorage */ .qQ)("avani_user", userData);
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_LOGIN_FAIL */ .P,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const userRegister = (name, phone, email, password)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_REGISTER_REQUEST */ .k1
            });
            const config = {
                headers: {
                    "Content-Type": "application/json"
                }
            };
            await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${_config__WEBPACK_IMPORTED_MODULE_0__/* .API */ .bl}/user`, {
                name,
                phone,
                email,
                password
            }, config);
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.info("Register Successfully", {
                autoClose: 700
            });
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_REGISTER_SUCCESS */ .hk
            });
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_REGISTER_FAIL */ .K_,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const userUpdate = (name, phone, email, password, userId)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_UPDATE_REQUEST */ .An
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`${_config__WEBPACK_IMPORTED_MODULE_0__/* .API */ .bl}/user/${userId}`, {
                name,
                phone,
                email,
                password
            }, config);
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.info("Profile Update Successfully", {
                autoClose: 700
            });
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_UPDATE_SUCCESS */ .dB
            });
            (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .removeCookie */ .nJ)("token");
            (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .removeLocalStorage */ .dZ)("avani_user");
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_UPDATE_FAIL */ .Sv,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const logout = ()=>async (dispatch)=>{
        (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .removeCookie */ .nJ)("token");
        (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .removeLocalStorage */ .dZ)("avani_user");
        dispatch({
            type: _constants_userConstant__WEBPACK_IMPORTED_MODULE_4__/* .USER_LOGOUT */ .lK
        });
    };

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$Z": () => (/* binding */ USER_LOGIN_RESET),
/* harmony export */   "An": () => (/* binding */ USER_UPDATE_REQUEST),
/* harmony export */   "K_": () => (/* binding */ USER_REGISTER_FAIL),
/* harmony export */   "P": () => (/* binding */ USER_LOGIN_FAIL),
/* harmony export */   "Sc": () => (/* binding */ USER_UPDATE_RESET),
/* harmony export */   "Sv": () => (/* binding */ USER_UPDATE_FAIL),
/* harmony export */   "dB": () => (/* binding */ USER_UPDATE_SUCCESS),
/* harmony export */   "hk": () => (/* binding */ USER_REGISTER_SUCCESS),
/* harmony export */   "k1": () => (/* binding */ USER_REGISTER_REQUEST),
/* harmony export */   "lK": () => (/* binding */ USER_LOGOUT),
/* harmony export */   "mA": () => (/* binding */ USER_LOGIN_REQUEST),
/* harmony export */   "wW": () => (/* binding */ USER_LOGIN_SUCCESS)
/* harmony export */ });
const USER_LOGIN_REQUEST = "USER_LOGIN_REQUEST";
const USER_LOGIN_SUCCESS = "USER_LOGIN_SUCCESS";
const USER_LOGIN_FAIL = "USER_LOGIN_FAIL";
const USER_LOGIN_RESET = "USER_LOGIN_RESET";
const USER_REGISTER_REQUEST = "USER_REGISTER_REQUEST";
const USER_REGISTER_SUCCESS = "USER_REGISTER_SUCCESS";
const USER_REGISTER_FAIL = "USER_REGISTER_FAIL";
const USER_UPDATE_REQUEST = "USER_UPDATE_REQUEST";
const USER_UPDATE_SUCCESS = "USER_UPDATE_SUCCESS";
const USER_UPDATE_FAIL = "USER_UPDATE_FAIL";
const USER_UPDATE_RESET = "USER_UPDATE_RESET";
const USER_LOGOUT = "USER_LOGOUT";


/***/ }),

/***/ 551:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$D": () => (/* binding */ isAuth),
/* harmony export */   "dZ": () => (/* binding */ removeLocalStorage),
/* harmony export */   "ej": () => (/* binding */ getCookie),
/* harmony export */   "lE": () => (/* binding */ setCookies),
/* harmony export */   "nJ": () => (/* binding */ removeCookie),
/* harmony export */   "qQ": () => (/* binding */ setLocalStorage)
/* harmony export */ });
/* unused harmony export authenticate */
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// set cookies
const setCookies = (key, value)=>{
    if (false) {}
};
// remove cookies
const removeCookie = (key)=>{
    if (false) {}
};
// get cookies
const getCookie = (key)=>{
    if (false) {}
};
// localstorage
const setLocalStorage = (key, value)=>{
    if (false) {}
};
// remove localstorge
const removeLocalStorage = (key)=>{
    if (false) {}
};
// authenticate user by passing data to cookie and localstorage
const authenticate = (data, next)=>{
    setCookies("token", data.token);
    setLocalStorage("avani_user", data.user);
    next();
};
// user info from localstorage
const isAuth = ()=>{
    if (false) {}
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;