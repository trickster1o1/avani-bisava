"use strict";
exports.id = 258;
exports.ids = [258];
exports.modules = {

/***/ 1022:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/product1.4dc8364e.jpg","height":320,"width":320,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAjgqf/8QAHBAAAQQDAQAAAAAAAAAAAAAAAQIDBSEABBFC/9oACAEBAAE/AItQfiAzzztOhVWaKRn/xAAYEQACAwAAAAAAAAAAAAAAAAAAAQIScf/aAAgBAgEBPwC8k3p//8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAC/9oACAEDAQE/ADA3/9k=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3258:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_avani_logo_jpg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8200);
/* harmony import */ var _public_product1_jpg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1022);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _redux_actions_cartAction__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9020);
/* harmony import */ var _redux_actions_productAction__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3762);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1838);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_actions_cartAction__WEBPACK_IMPORTED_MODULE_8__, _redux_actions_productAction__WEBPACK_IMPORTED_MODULE_9__]);
([_redux_actions_cartAction__WEBPACK_IMPORTED_MODULE_8__, _redux_actions_productAction__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







// import { addToCart } from "../actions/cart";




const ProductCard = ({ value  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const userLoginState = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.userLogin);
    const { userInfo  } = userLoginState;
    const { 0: isLoading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    function cn(...classes) {
        return classes.filter(Boolean).join(" ");
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "md:h-[400px] m-2 bg-white product__item",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "product__item__pic",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                        href: `/product/${value.slug}?main_category=${value.main_category}`,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            onClick: ()=>dispatch((0,_redux_actions_productAction__WEBPACK_IMPORTED_MODULE_9__/* .updateProductToTrending */ .P4)(value.uuid)),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "aspect-w-1 aspect-h-1 w-full overflow-hidden bg-gray-200 xl:aspect-w-3 xl:aspect-h-3",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: `${_config__WEBPACK_IMPORTED_MODULE_10__/* .baseUrl */ .FH}/${value.image}`,
                                        layout: "fill",
                                        objectFit: "cover",
                                        className: cn("duration-700 ease-in-out group-hover:opacity-75 rounded-t-sm", isLoading ? "scale-110 blur-2xl grayscale rounded-t-sm" : "scale-100 blur-0 grayscale-0 rounded-t-sm"),
                                        onLoadingComplete: ()=>setLoading(false)
                                    })
                                }),
                                value.price_discount > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "absolute top-[1px] right-[1px] bg-white px-3",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            value.price_discount,
                                            "% OFF"
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "product__item__hover",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "h-6 w-6",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            stroke: "currentColor",
                                            strokeWidth: 2,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "cursor-pointer",
                                    onClick: (e)=>dispatch((0,_redux_actions_cartAction__WEBPACK_IMPORTED_MODULE_8__/* .addToCart */ .Xq)(value.uuid, 1)),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "h-6 w-6",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            stroke: "currentColor",
                                            strokeWidth: 2,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "cursor-pointer",
                                    onClick: ()=>dispatch((0,_redux_actions_productAction__WEBPACK_IMPORTED_MODULE_9__/* .createLovedProduct */ .nX)(userInfo.uuid, value.uuid)),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "h-6 w-6",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            stroke: "currentColor",
                                            strokeWidth: 2,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                                            })
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-1 product__item__text",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        className: "text-xl font-semibold text-gray-900 text-center",
                        children: value.name
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-1 h-[50px] relative overflow-hidden flex justify-center items-center",
                        children: [
                            value.price_discount > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "font-bold text-gray-700 text-center price",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "line-through mr-3",
                                        children: [
                                            "MRP: Rs. ",
                                            value.price
                                        ]
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "OFFER PRICE: Rs.",
                                    " ",
                                    Math.round(value.price - value.price * value.price_discount / 100)
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: " font-bold text-xl text-gray-700 text-center price",
                                children: [
                                    "MRP: Rs. ",
                                    value.price
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "cart-btn-container cursor-pointer",
                                onClick: (e)=>dispatch((0,_redux_actions_cartAction__WEBPACK_IMPORTED_MODULE_8__/* .addToCart */ .Xq)(value.uuid, 1)),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "cart-btn",
                                    children: "Add to cart"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3762:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lc": () => (/* binding */ getLovedProductByUserId),
/* harmony export */   "P4": () => (/* binding */ updateProductToTrending),
/* harmony export */   "nE": () => (/* binding */ createProductReview),
/* harmony export */   "nX": () => (/* binding */ createLovedProduct)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1838);
/* harmony import */ var _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8266);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(551);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const updateProductToTrending = (productId)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .PRODUCT_UPDATE_TO_TRENDING_REQUEST */ .QK
            });
            const config = {
                headers: {
                    "Content-Type": "application/json"
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/product/${productId}/trending`, {}, config);
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .PRODUCT_UPDATE_TO_TRENDING_SUCCESS */ .m0,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .PRODUCT_UPDATE_TO_TRENDING_FAIL */ .zh,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const createLovedProduct = (userId, productId)=>async (dispatch, getState)=>{
        try {
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .CREATE_LOVED_PRODUCT_REQUEST */ .O3
            });
            const { userLogin: { userInfo  } ,  } = getState();
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/lovedProduct`, {
                userId,
                productId
            }, config);
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .CREATE_LOVED_PRODUCT_SUCCESS */ .EQ,
                payload: data
            });
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.info("Product Loved", {
                autoClose: 700
            });
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error("Login To React This Product", {
                autoClose: 700
            });
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .CREATE_LOVED_PRODUCT_FAIL */ .Rb,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const getLovedProductByUserId = (userId)=>async (dispatch, getState)=>{
        try {
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .GET_LOVED_PRODUCT_REQUEST */ .Pb
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/lovedProduct/${userId}`, config);
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .GET_LOVED_PRODUCT_SUCCESS */ .Cj,
                payload: data.products
            });
        } catch (err) {
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .GET_LOVED_PRODUCT_FAIL */ .P8,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const createProductReview = (rating, comment, user_id, product_id)=>async (dispatch, getState)=>{
        try {
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .CREATE_PRODUCT_REVIEW_REQUEST */ .Q2
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/review`, {
                rating,
                comment,
                user_id,
                product_id
            }, config);
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .CREATE_PRODUCT_REVIEW_SUCCESS */ .aW,
                payload: data
            });
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.info("Review Added To This Product", {
                autoClose: 700
            });
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_productConstant__WEBPACK_IMPORTED_MODULE_4__/* .CREATE_PRODUCT_REVIEW_FAIL */ .H,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;