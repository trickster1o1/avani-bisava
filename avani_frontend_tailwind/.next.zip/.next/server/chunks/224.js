"use strict";
exports.id = 224;
exports.ids = [224];
exports.modules = {

/***/ 4224:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports registerUser, siginin, setCookies, removeCookie, getCookie, setLocalStorage, removeLocalStorage, authenticate */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6583);
/* harmony import */ var isomorphic_fetch__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(isomorphic_fetch__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1838);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3590);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_3__, js_cookie__WEBPACK_IMPORTED_MODULE_4__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_3__, js_cookie__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const registerUser = async (name, phone, email, password)=>{
    try {
        const config = {
            headers: {
                "Content-Type": "application/json"
            }
        };
        const { data  } = await axios.post(`${API}/user`, {
            name,
            phone,
            email,
            password
        }, config);
        toast.info("Register Successfully", {
            autoClose: 1000
        });
        return data;
    } catch (err) {
        toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
            autoClose: 1000
        });
        return true;
    // console.log(
    //   err.response && err.response.data.message
    //     ? err.response.data.message
    //     : err.message
    // );
    // dispatch({
    //   type: PRODUCT_ADD_FAIL,
    //   payload:
    //     err.response && err.response.data.message
    //       ? err.response.data.message
    //       : err.message,
    // });
    }
};
const siginin = async (email, password)=>{
    try {
        const config = {
            headers: {
                "Content-Type": "application/json"
            }
        };
        const { data  } = await axios.post(`${API}/user/login`, {
            email,
            password
        }, config);
        toast.info("Login Successfully", {
            autoClose: 1000
        });
        return data;
    } catch (err) {
        toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
            autoClose: 1000
        });
        return true;
    }
};
// set cookies
const setCookies = (key, value)=>{
    if (false) {}
};
// remove cookies
const removeCookie = (key)=>{
    if (false) {}
};
// get cookies
const getCookie = (key)=>{
    if (false) {}
};
// localstorage
const setLocalStorage = (key, value)=>{
    if (false) {}
};
// remove localstorge
const removeLocalStorage = (key)=>{
    if (false) {}
};
// authenticate user by passing data to cookie and localstorage
const authenticate = (data, next)=>{
    setCookies("token", data.token);
    setLocalStorage("user", data.user);
    next();
}; // user info from localstorage
 // export const isAuth = () => {
 //   if (process.browser) {
 //     const cookieChecked = getCookie("token");
 //     if (cookieChecked) {
 //       if (localStorage.getItem("user")) {
 //         return JSON.parse(localStorage.getItem("user"));
 //       } else {
 //         return false;
 //       }
 //     }
 //   }
 // };

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;