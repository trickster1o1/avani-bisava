"use strict";
exports.id = 999;
exports.ids = [999];
exports.modules = {

/***/ 1999:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tn": () => (/* binding */ createOrders),
/* harmony export */   "ak": () => (/* binding */ getOrdersByUserId),
/* harmony export */   "co": () => (/* binding */ getOrder)
/* harmony export */ });
/* unused harmony exports getOrders, payOrder, deliverOrder */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3590);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1838);
/* harmony import */ var _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6220);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(551);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const getOrders = ()=>async (dispatch)=>{
        try {
            dispatch({
                type: ORDER_LIST_REQUEST
            });
            const config = {
                headers: {
                    "Content-Type": "application/json"
                }
            };
            const { data  } = await axios.get(`${API}/order`, config);
            dispatch({
                type: ORDER_LIST_SUCCESS,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: ORDER_LIST_FAIL,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const getOrdersByUserId = (uuid)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_LIST_BY_USERID_REQUEST */ .RQ
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/order/user/${uuid}`, config);
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_LIST_BY_USERID_SUCCESS */ .yV,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_LIST_BY_USERID_FAIL */ .xg,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const getOrder = (uuid)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_DETAILS_REQUEST */ .YO
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/order/${uuid}`, config);
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_DETAILS_SUCCESS */ .um,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_DETAILS_FAIL */ .Ab,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const createOrders = (order)=>async (dispatch)=>{
        try {
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_ADD_REQUEST */ .MB
            });
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .getCookie */ .ej)("token")}`
                }
            };
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${_config__WEBPACK_IMPORTED_MODULE_2__/* .API */ .bl}/order`, order, config);
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_ADD_SUCCESS */ .MM,
                payload: data
            });
        } catch (err) {
            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.error(err.response && err.response.data.message ? err.response.data.message : err.message, {
                autoClose: 700
            });
            dispatch({
                type: _constants_orderConstant__WEBPACK_IMPORTED_MODULE_4__/* .ORDER_ADD_FAIL */ .YY,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const payOrder = (orderId)=>async (dispatch, getState)=>{
        try {
            dispatch({
                type: ORDER_UPDATE_TO_PAY_REQUEST
            });
            const { userLogin: { userInfo  } ,  } = getState();
            const config = {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${userInfo.token}`
                }
            };
            const { data  } = await axios.put(`${API}/order/${orderId}/pay`, {}, config);
            dispatch({
                type: ORDER_UPDATE_TO_PAY_SUCCESS,
                payload: data
            });
        } catch (err) {
            dispatch({
                type: ORDER_UPDATE_TO_PAY_FAIL,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };
const deliverOrder = (uuid)=>async (dispatch, getState)=>{
        try {
            dispatch({
                type: ORDER_UPDATE_TO_DELIVERED_REQUEST
            });
            const { userLogin: { userInfo  } ,  } = getState();
            const config = {
                headers: {
                    Authorization: `Bearer ${userInfo.token}`
                }
            };
            await axios.put(`${API}/order/${uuid}/deliver`, {}, config);
            dispatch({
                type: ORDER_UPDATE_TO_DELIVERED_SUCCESS
            });
        } catch (err) {
            dispatch({
                type: ORDER_UPDATE_TO_DELIVERED_FAIL,
                payload: err.response && err.response.data.message ? err.response.data.message : err.message
            });
        }
    };

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;