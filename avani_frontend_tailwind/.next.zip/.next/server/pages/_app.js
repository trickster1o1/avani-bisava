(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ MyApp)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3071);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__, _redux_store__WEBPACK_IMPORTED_MODULE_4__]);
([react_toastify__WEBPACK_IMPORTED_MODULE_2__, _redux_store__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











// This default export is required in a new `pages/_app.js` file.
function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_5___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: "Avani Nepal"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_redux__WEBPACK_IMPORTED_MODULE_3__.Provider, {
                store: _redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {})
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2562:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nw": () => (/* binding */ CART_ADD_ITEM),
/* harmony export */   "TU": () => (/* binding */ CART_SAVE_PAYMENT_METHOD),
/* harmony export */   "aR": () => (/* binding */ CART_REMOVE_ITEM),
/* harmony export */   "ko": () => (/* binding */ CART_SAVE_SHIPPING_ADDRESS)
/* harmony export */ });
const CART_ADD_ITEM = "CART_ADD_ITEM";
const CART_REMOVE_ITEM = "CART_REMOVE_ITEM";
const CART_SAVE_SHIPPING_ADDRESS = "CART_SAVE_SHIPPING_ADDRESS";
const CART_SAVE_PAYMENT_METHOD = "CART_SAVE_PAYMENT_METHOD";


/***/ }),

/***/ 7526:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$Z": () => (/* binding */ USER_LOGIN_RESET),
/* harmony export */   "An": () => (/* binding */ USER_UPDATE_REQUEST),
/* harmony export */   "K_": () => (/* binding */ USER_REGISTER_FAIL),
/* harmony export */   "P": () => (/* binding */ USER_LOGIN_FAIL),
/* harmony export */   "Sc": () => (/* binding */ USER_UPDATE_RESET),
/* harmony export */   "Sv": () => (/* binding */ USER_UPDATE_FAIL),
/* harmony export */   "dB": () => (/* binding */ USER_UPDATE_SUCCESS),
/* harmony export */   "hk": () => (/* binding */ USER_REGISTER_SUCCESS),
/* harmony export */   "k1": () => (/* binding */ USER_REGISTER_REQUEST),
/* harmony export */   "lK": () => (/* binding */ USER_LOGOUT),
/* harmony export */   "mA": () => (/* binding */ USER_LOGIN_REQUEST),
/* harmony export */   "wW": () => (/* binding */ USER_LOGIN_SUCCESS)
/* harmony export */ });
const USER_LOGIN_REQUEST = "USER_LOGIN_REQUEST";
const USER_LOGIN_SUCCESS = "USER_LOGIN_SUCCESS";
const USER_LOGIN_FAIL = "USER_LOGIN_FAIL";
const USER_LOGIN_RESET = "USER_LOGIN_RESET";
const USER_REGISTER_REQUEST = "USER_REGISTER_REQUEST";
const USER_REGISTER_SUCCESS = "USER_REGISTER_SUCCESS";
const USER_REGISTER_FAIL = "USER_REGISTER_FAIL";
const USER_UPDATE_REQUEST = "USER_UPDATE_REQUEST";
const USER_UPDATE_SUCCESS = "USER_UPDATE_SUCCESS";
const USER_UPDATE_FAIL = "USER_UPDATE_FAIL";
const USER_UPDATE_RESET = "USER_UPDATE_RESET";
const USER_LOGOUT = "USER_LOGOUT";


/***/ }),

/***/ 1509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ab": () => (/* binding */ listBlogsReducer),
/* harmony export */   "Sb": () => (/* binding */ createBlogReducer),
/* harmony export */   "Yy": () => (/* binding */ deleteBlogReducer),
/* harmony export */   "_d": () => (/* binding */ listBlogsByUserIdReducer),
/* harmony export */   "bQ": () => (/* binding */ listBlogReducer),
/* harmony export */   "qu": () => (/* binding */ updateBlogReducer)
/* harmony export */ });
/* harmony import */ var _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5047);

const listBlogsReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_LIST_REQUEST */ .tW:
            return {
                loading: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_LIST_SUCCESS */ .Yz:
            return {
                loading: false,
                blogs: action.payload
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_LIST_FAIL */ .am:
            return {
                loading: true,
                error: action.payload
            };
        default:
            return state;
    }
};
const listBlogsByUserIdReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_LIST_BY_USERID_REQUEST */ .j0:
            return {
                loading: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_LIST_BY_USERID_SUCCESS */ .xz:
            return {
                loading: false,
                blogs: action.payload
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_LIST_BY_USERID_FAIL */ .lI:
            return {
                loading: true,
                error: action.payload
            };
        default:
            return state;
    }
};
const listBlogReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_DETAILS_REQUEST */ .FB:
            return {
                loading: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_DETAILS_SUCCESS */ .hG:
            return {
                loading: false,
                blog: action.payload
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_DETAILS_FAIL */ .jS:
            return {
                loading: true,
                error: action.payload
            };
        default:
            return state;
    }
};
const createBlogReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_ADD_REQUEST */ .CG:
            return {
                loading: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_ADD_SUCCESS */ .EL:
            return {
                loading: false,
                success: true,
                blogs: action.payload
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_ADD_FAIL */ .DJ:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_ADD_RESET */ .Ax:
            return {};
        default:
            return state;
    }
};
const updateBlogReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_UPDATE_REQUEST */ .tj:
            return {
                loading: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_UPDATE_SUCCESS */ .cW:
            return {
                loading: false,
                success: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_UPDATE_FAIL */ .MY:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_UPDATE_RESET */ .B8:
            return {};
        default:
            return state;
    }
};
const deleteBlogReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_DELETE_REQUEST */ .gL:
            return {
                loading: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_DELETE_SUCCESS */ .Ke:
            return {
                loading: false,
                success: true
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_DELETE_FAIL */ .M7:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        case _constants_blogConstant__WEBPACK_IMPORTED_MODULE_0__/* .BLOG_DELETE_RESET */ .SL:
            return {};
        default:
            return state;
    }
};


/***/ }),

/***/ 4238:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ productAddToCartReducer)
/* harmony export */ });
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3590);
/* harmony import */ var _constants_cartConstant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2562);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_0__]);
react_toastify__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const cartItemsFromStorage =  false ? 0 : [];
const shippingAddressFromStorage =  false ? 0 : null;
const paymentMethodFromStorage =  false ? 0 : "";
const initialState = {
    cartItems: cartItemsFromStorage,
    shippingAddress: shippingAddressFromStorage,
    paymentMethod: paymentMethodFromStorage
};
const productAddToCartReducer = (state = initialState, action)=>{
    switch(action.type){
        case _constants_cartConstant__WEBPACK_IMPORTED_MODULE_1__/* .CART_ADD_ITEM */ .Nw:
            const item = action.payload;
            const exitItem = state.cartItems.find((x)=>x.uuid === item.uuid);
            if (exitItem) {
                react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.success("Product Update To Cart", {
                    autoClose: 700
                });
                return {
                    ...state,
                    cartItems: state.cartItems.map((x)=>x.uuid === exitItem.uuid ? item : x)
                };
            } else {
                react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.info("Product Added To Cart", {
                    autoClose: 700
                });
                return {
                    ...state,
                    cartItems: [
                        ...state.cartItems,
                        item
                    ]
                };
            }
        case _constants_cartConstant__WEBPACK_IMPORTED_MODULE_1__/* .CART_REMOVE_ITEM */ .aR:
            react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.info("Product Removed From Cart", {
                autoClose: 700
            });
            return {
                ...state,
                cartItems: state.cartItems.filter((item)=>item.uuid !== action.payload)
            };
        case _constants_cartConstant__WEBPACK_IMPORTED_MODULE_1__/* .CART_SAVE_SHIPPING_ADDRESS */ .ko:
            return {
                ...state,
                shippingAddress: action.payload
            };
        case _constants_cartConstant__WEBPACK_IMPORTED_MODULE_1__/* .CART_SAVE_PAYMENT_METHOD */ .TU:
            return {
                ...state,
                paymentMethod: action.payload
            };
        default:
            return state;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$l": () => (/* binding */ listOrderReducer),
/* harmony export */   "Kd": () => (/* binding */ listOrdersReducer),
/* harmony export */   "dW": () => (/* binding */ createOrdersReducer),
/* harmony export */   "io": () => (/* binding */ orderPayReducer),
/* harmony export */   "vw": () => (/* binding */ listOrdersByUserIdReducer)
/* harmony export */ });
/* unused harmony export orderDeliverReducer */
/* harmony import */ var _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6220);

const listOrdersReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_LIST_REQUEST */ .cB:
            return {
                loading: true
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_LIST_SUCCESS */ .zL:
            return {
                loading: false,
                orders: action.payload
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_LIST_FAIL */ .E0:
            return {
                loading: true,
                error: action.payload
            };
        default:
            return state;
    }
};
const listOrdersByUserIdReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_LIST_BY_USERID_REQUEST */ .RQ:
            return {
                loading: true
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_LIST_BY_USERID_SUCCESS */ .yV:
            return {
                loading: false,
                orders: action.payload
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_LIST_BY_USERID_FAIL */ .xg:
            return {
                loading: true,
                error: action.payload
            };
        default:
            return state;
    }
};
const listOrderReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_DETAILS_REQUEST */ .YO:
            return {
                loading: true
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_DETAILS_SUCCESS */ .um:
            return {
                loading: false,
                order: action.payload
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_DETAILS_FAIL */ .Ab:
            return {
                loading: true,
                error: action.payload
            };
        default:
            return state;
    }
};
const createOrdersReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_ADD_REQUEST */ .MB:
            return {
                loading: true
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_ADD_SUCCESS */ .MM:
            return {
                loading: false,
                success: true,
                orders: action.payload
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_ADD_FAIL */ .YY:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_ADD_RESET */ .Ut:
            return {};
        default:
            return state;
    }
};
const orderPayReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_UPDATE_TO_PAY_REQUEST */ .bt:
            return {
                loading: true
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_UPDATE_TO_PAY_SUCCESS */ .gV:
            return {
                loading: false,
                success: true
            };
        case _constants_orderConstant__WEBPACK_IMPORTED_MODULE_0__/* .ORDER_UPDATE_TO_PAY_FAIL */ ._4:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        default:
            return state;
    }
};
const orderDeliverReducer = (state = {}, action)=>{
    switch(action.type){
        case ORDER_UPDATE_TO_DELIVERED_REQUEST:
            return {
                loading: true
            };
        case ORDER_UPDATE_TO_DELIVERED_SUCCESS:
            return {
                loading: false,
                success: true
            };
        case ORDER_UPDATE_TO_DELIVERED_FAIL:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        default:
            return state;
    }
};


/***/ }),

/***/ 9580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$g": () => (/* binding */ createLovedProductReducer),
/* harmony export */   "C2": () => (/* binding */ getLovedProductByUserIdReducer),
/* harmony export */   "Lh": () => (/* binding */ createProductReviewReducer),
/* harmony export */   "QY": () => (/* binding */ productTrendingReducer)
/* harmony export */ });
/* harmony import */ var _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8266);

const productTrendingReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .PRODUCT_UPDATE_TO_TRENDING_REQUEST */ .QK:
            return {
                loading: true
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .PRODUCT_UPDATE_TO_TRENDING_SUCCESS */ .m0:
            return {
                loading: false,
                success: true
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .PRODUCT_UPDATE_TO_TRENDING_FAIL */ .zh:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        default:
            return state;
    }
};
const createLovedProductReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_LOVED_PRODUCT_REQUEST */ .O3:
            return {
                loading: true
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_LOVED_PRODUCT_SUCCESS */ .EQ:
            return {
                loading: false,
                success: true
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_LOVED_PRODUCT_FAIL */ .Rb:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        default:
            return state;
    }
};
const getLovedProductByUserIdReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .GET_LOVED_PRODUCT_REQUEST */ .Pb:
            return {
                loading: true
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .GET_LOVED_PRODUCT_SUCCESS */ .Cj:
            return {
                loading: false,
                success: true,
                products: action.payload
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .GET_LOVED_PRODUCT_FAIL */ .P8:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        default:
            return state;
    }
};
const createProductReviewReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_PRODUCT_REVIEW_REQUEST */ .Q2:
            return {
                loading: true
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_PRODUCT_REVIEW_SUCCESS */ .aW:
            return {
                loading: false,
                success: true
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_PRODUCT_REVIEW_FAIL */ .H:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        case _constants_productConstant__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_PRODUCT_REVIEW_RESET */ .Oc:
            return {};
        default:
            return state;
    }
};


/***/ }),

/***/ 4884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ userUpdateReducer),
/* harmony export */   "j": () => (/* binding */ userLoginReducer)
/* harmony export */ });
/* harmony import */ var _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7526);

const userLoginReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_LOGIN_REQUEST */ .mA:
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_REGISTER_REQUEST */ .k1:
            return {
                loading: true
            };
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_LOGIN_SUCCESS */ .wW:
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_REGISTER_SUCCESS */ .hk:
            return {
                loading: false,
                success: true,
                userInfo: action.payload
            };
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_LOGIN_FAIL */ .P:
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_REGISTER_FAIL */ .K_:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_LOGIN_RESET */ .$Z:
            return {
                loading: false,
                userInfo: null
            };
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_LOGOUT */ .lK:
            return {};
        default:
            return state;
    }
};
const userUpdateReducer = (state = {}, action)=>{
    switch(action.type){
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_UPDATE_REQUEST */ .An:
            return {
                loading: true
            };
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_UPDATE_SUCCESS */ .dB:
            return {
                loading: false,
                success: true
            };
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_UPDATE_FAIL */ .Sv:
            return {
                loading: true,
                success: false,
                error: action.payload
            };
        case _constants_userConstant__WEBPACK_IMPORTED_MODULE_0__/* .USER_UPDATE_RESET */ .Sc:
            return {};
        default:
            return state;
    }
};


/***/ }),

/***/ 3071:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6695);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(173);
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8417);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_thunk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _reducers_userReducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4884);
/* harmony import */ var _reducers_cartReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4238);
/* harmony import */ var _reducers_orderReducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5189);
/* harmony import */ var _reducers_productReducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9580);
/* harmony import */ var _reducers_blogReducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1509);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reducers_cartReducer__WEBPACK_IMPORTED_MODULE_4__]);
_reducers_cartReducer__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const reducer = (0,redux__WEBPACK_IMPORTED_MODULE_0__.combineReducers)({
    userLogin: _reducers_userReducer__WEBPACK_IMPORTED_MODULE_5__/* .userLoginReducer */ .j,
    userUpdate: _reducers_userReducer__WEBPACK_IMPORTED_MODULE_5__/* .userUpdateReducer */ .e,
    productAddToCart: _reducers_cartReducer__WEBPACK_IMPORTED_MODULE_4__/* .productAddToCartReducer */ .T,
    listOrders: _reducers_orderReducer__WEBPACK_IMPORTED_MODULE_6__/* .listOrdersReducer */ .Kd,
    listOrdersByUserId: _reducers_orderReducer__WEBPACK_IMPORTED_MODULE_6__/* .listOrdersByUserIdReducer */ .vw,
    listOrder: _reducers_orderReducer__WEBPACK_IMPORTED_MODULE_6__/* .listOrderReducer */ .$l,
    createOrders: _reducers_orderReducer__WEBPACK_IMPORTED_MODULE_6__/* .createOrdersReducer */ .dW,
    orderPay: _reducers_orderReducer__WEBPACK_IMPORTED_MODULE_6__/* .orderPayReducer */ .io,
    productTrending: _reducers_productReducer__WEBPACK_IMPORTED_MODULE_7__/* .productTrendingReducer */ .QY,
    createLovedProduct: _reducers_productReducer__WEBPACK_IMPORTED_MODULE_7__/* .createLovedProductReducer */ .$g,
    getLovedProductByUserId: _reducers_productReducer__WEBPACK_IMPORTED_MODULE_7__/* .getLovedProductByUserIdReducer */ .C2,
    listBlogs: _reducers_blogReducer__WEBPACK_IMPORTED_MODULE_8__/* .listBlogsReducer */ .Ab,
    listBlog: _reducers_blogReducer__WEBPACK_IMPORTED_MODULE_8__/* .listBlogReducer */ .bQ,
    createBlog: _reducers_blogReducer__WEBPACK_IMPORTED_MODULE_8__/* .createBlogReducer */ .Sb,
    updateBlog: _reducers_blogReducer__WEBPACK_IMPORTED_MODULE_8__/* .updateBlogReducer */ .qu,
    listBlogsByUserId: _reducers_blogReducer__WEBPACK_IMPORTED_MODULE_8__/* .listBlogsByUserIdReducer */ ._d,
    deleteBlog: _reducers_blogReducer__WEBPACK_IMPORTED_MODULE_8__/* .deleteBlogReducer */ .Yy,
    createProductReview: _reducers_productReducer__WEBPACK_IMPORTED_MODULE_7__/* .createProductReviewReducer */ .Lh
});
const adminInfoFromStrorage =  false ? 0 : null;
const initialState = {
    userLogin: {
        userInfo: adminInfoFromStrorage
    }
};
const middleware = [
    (redux_thunk__WEBPACK_IMPORTED_MODULE_2___default())
];
const store = (0,redux__WEBPACK_IMPORTED_MODULE_0__.createStore)(reducer, initialState, (0,redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1__.composeWithDevTools)((0,redux__WEBPACK_IMPORTED_MODULE_0__.applyMiddleware)(...middleware)));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store); // "next": "12.2.2",
 // "react": "18.2.0",
 // "react-dom": "18.2.0",

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("redux");

/***/ }),

/***/ 173:
/***/ ((module) => {

"use strict";
module.exports = require("redux-devtools-extension");

/***/ }),

/***/ 8417:
/***/ ((module) => {

"use strict";
module.exports = require("redux-thunk");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [47,266,220], () => (__webpack_exec__(8510)));
module.exports = __webpack_exports__;

})();