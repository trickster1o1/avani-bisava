"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 8768:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/show1.f07c0292.jpg","height":1595,"width":4032,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAMACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAAAQEBAQAAAAAAAAAAAAAAAAAAAgX/2gAMAwEAAhADEAAAAKJi/8QAHBAAAQMFAAAAAAAAAAAAAAAAAgEREgADBRMx/9oACAEBAAE/ALzLjzNQCWmTwTtf/8QAGREBAAIDAAAAAAAAAAAAAAAAAQARAwQi/9oACAECAQE/ANtRx01zP//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 1122:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/show3.c51cfb66.webp","height":500,"width":1500,"blurDataURL":"data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAMAAkA4JYwCdAEPAKU4AAD+9V0+KLS4a7HtqdYTSHu89WuNY8pAAAA=","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 746:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/show5.e604a34d.webp","height":935,"width":1500,"blurDataURL":"data:image/webp;base64,UklGRjwAAABXRUJQVlA4IDAAAADQAQCdASoIAAUAAkA4JZQCdAEfhwwFAAD++znDpAac1uGNMeSJ5giuq60iMM/V4AA=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 9263:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/show6.e81682f8.webp","height":747,"width":1200,"blurDataURL":"data:image/webp;base64,UklGRkwAAABXRUJQVlA4IEAAAADQAQCdASoIAAUAAkA4JbACdAD0eqr5AADifefbwueZiiKC4UToWTWFrJ8X9CvvtTzGX/XeWJreOkWrp7nUoAAA","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 5337:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CustomSlider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _data_testi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1828);




function CustomSlider() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "slider-cont",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Carousel, {
            children: _data_testi__WEBPACK_IMPORTED_MODULE_3__/* .banners.length */ .T.length ? _data_testi__WEBPACK_IMPORTED_MODULE_3__/* .banners.map */ .T.map((b, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full h-full",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "c-overlay",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-1/2 h-full flex flex-col justify-center items-center p-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-lg p-10 text-[white] flex flex-col justify-end",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "text-4xl mb-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                dangerouslySetInnerHTML: {
                                                    __html: b.header
                                                }
                                            })
                                        }),
                                        b.desc,
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: b.link,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "block w-fit custom-btn pt-[.5em] pb-[.5em] pl-[3em] pr-[3em] text-white hover:text-[rgba(0,0,0,.5)] border border-[white] mt-10 mb-5",
                                                children: b.btn
                                            })
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            alt: "...",
                            src: b.img,
                            style: b.style ? b.style : null
                        })
                    ]
                }, index)) : null
        })
    });
}


/***/ }),

/***/ 7877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ IgSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2369);


function IgSection() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Container__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col justify-center items-center bg-[#fffafe] ig-cont pb-5 mb-10",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-xl pt-10",
                    children: "@avaninepal"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: "https://www.instagram.com/avaninepal/",
                    target: "_blank",
                    className: "custom-btn mt-2 border pt-[.5em] pb-[.5em] pl-[3em] pr-[3em] border-black text-[rgba(0,0,0,.5)]",
                    children: "Follow us"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-2 lg:grid-cols-5 gap-2 pb-10 pt-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "cursor-pointer h-[200px] overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.instagram.com/p/CrLyChctJWH/",
                                target: "_blank",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/ig/a.png",
                                    className: "w-full"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "cursor-pointer h-[200px] overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.instagram.com/p/CqVg9PvtVjU/",
                                target: "_blank",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/ig/b.png"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "cursor-pointer h-[200px] overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.instagram.com/p/CqQgNAgtiaQ/",
                                target: "_blank",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/ig/c.png"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "cursor-pointer h-[200px] overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.instagram.com/p/CknSWwVse3J/",
                                target: "_blank",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/ig/d.png"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "cursor-pointer h-[200px] overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.instagram.com/p/Cg6OokAsnnX/",
                                target: "_blank",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/ig/e.png"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                    href: "https://www.instagram.com/avaninepal/",
                    target: "_blank",
                    className: "custom-btn pt-[.5em] pb-[.5em] pl-[3em] pr-[3em] bg-[#0095f6] text-white hover:text-[rgba(0,0,0,.5)]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/ig.svg",
                            alt: "IG",
                            className: "w-[.8em] mr-1 inline"
                        }),
                        " View on Instagram"
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 7736:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_product1_jpg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1022);
/* harmony import */ var _public_show1_jpg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8768);
/* harmony import */ var _public_show3_webp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1122);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1838);











function SampleNextArrow(props) {
    const { className , style , onClick  } = props;
    return /*#__PURE__*/ _jsx("div", {
        className: className,
        style: {
            ...style,
            right: "23px",
            fontSize: "40px !important"
        },
        onClick: onClick
    });
}
function SamplePrevArrow(props) {
    const { className , style , onClick  } = props;
    return /*#__PURE__*/ _jsx("div", {
        className: className,
        style: {
            ...style,
            left: "10px !important",
            zIndex: "100"
        },
        onClick: onClick
    });
}
const ImageSlider = ({ banners  })=>{
    const { 0: isLoading , 1: setLoading  } = useState(true);
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        nextArrow: /*#__PURE__*/ _jsx(SampleNextArrow, {}),
        prevArrow: /*#__PURE__*/ _jsx(SamplePrevArrow, {}),
        autoplay: true
    };
    console.log(banners.filter((value)=>value.type === 0));
    function cn(...classes) {
        return classes.filter(Boolean).join(" ");
    }
    return /*#__PURE__*/ _jsx("div", {
        children: /*#__PURE__*/ _jsx(Slider, {
            ...settings,
            children: banners.filter((value)=>value.type === 0).map((banner)=>/*#__PURE__*/ _jsx("div", {
                    className: " w-full h-48 md:h-96 overflow-hidden bg-gray-200 relative",
                    children: /*#__PURE__*/ _jsx(Link, {
                        href: `/product/${banner.product.slug}?main_category=${banner.product.main_category}`,
                        children: /*#__PURE__*/ _jsx("a", {
                            children: /*#__PURE__*/ _jsx(Image, {
                                alt: "Mountains",
                                src: `${baseUrl}/${banner.image}`,
                                priority: true,
                                objectFit: "cover",
                                layout: "fill"
                            })
                        })
                    })
                }))
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ImageSlider)));


/***/ }),

/***/ 6853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Organic)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2369);


function Organic() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Container__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "grid grid-cols-2 lg:grid-cols-5 gap-6 pb-10 org-cont bg-[#fffafe] pt-10 mb-5",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "duration-300 cursor-pointer flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/organic/organic.png",
                            alt: "Scientifically Formulated"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "flex items-center w-ful h-12 uppercase text-center",
                            children: "Organic"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "duration-300 cursor-pointer flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/organic/crueltyfree.png",
                            alt: "Scientifically Formulated"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "flex items-center w-ful h-12 uppercase text-center",
                            children: "Cruelty Free"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "duration-300 cursor-pointer flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/organic/certified.png",
                            alt: "Scientifically Formulated"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "flex items-center w-ful h-12 uppercase text-center",
                            children: "Certified"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "duration-300 cursor-pointer flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/organic/recycle.png",
                            alt: "Scientifically Formulated"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "flex items-center w-ful h-12 uppercase text-center",
                            children: "Sustainable"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "duration-300 cursor-pointer flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/organic/antioxident.png",
                            alt: "Scientifically Formulated"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "flex items-center w-ful h-12 uppercase text-center",
                            children: "antioxidant"
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 9741:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Promise() {
    return /*#__PURE__*/ _jsx("div", {
        className: "relative overflow-hidden promise-cont",
        children: /*#__PURE__*/ _jsx("img", {
            src: "/fb.png",
            style: {
                "width": "100%",
                "height": "auto"
            }
        })
    });
}


/***/ }),

/***/ 6986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Testimonial)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _data_testi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1828);



function Testimonial() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-[415px] flex justify-center items-center testi-cont",
        style: {
            margin: "0",
            position: "relative",
            backgroundImage: 'url("/testiB.jpeg")',
            backgroundSize: "cover",
            backgroundAttachment: "fixed",
            backgroundPosition: "center"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute top-0 left-0 w-full h-full bg-[rgba(255,255,255,.2)]"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(flowbite_react__WEBPACK_IMPORTED_MODULE_1__.Carousel, {
                indicators: false,
                slideInterval: 11000,
                children: _data_testi__WEBPACK_IMPORTED_MODULE_2__/* .testiData */ .B ? _data_testi__WEBPACK_IMPORTED_MODULE_2__/* .testiData.map */ .B.map((t, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-5/6 flex justify-center h-5/6 pt-5 overflow-hidden testi-cont",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-2/6 testi-name",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-2xl block w-full overflow-hidden mb-2 text-[#a37292]",
                                        children: "Testimonials"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-5xl text-[#6b8874] block w-full overflow-hidden",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            dangerouslySetInnerHTML: {
                                                __html: t.name
                                            }
                                        })
                                    }),
                                    t.designation ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-2xl block w-full overflow-hidden mt-1 text-[#a37292]",
                                        children: t.designation
                                    }) : null
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-2/6 text-left pl-6 h-fit text-lg text-[#6b8874] font-bold",
                                style: {
                                    borderLeft: "1px solid rgba(0,0,0,.2)"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    dangerouslySetInnerHTML: {
                                        __html: t.testi
                                    }
                                })
                            })
                        ]
                    }, index)) : null
            })
        ]
    });
}


/***/ }),

/***/ 3890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ YtdSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2369);


function YtdSection() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Container__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "grid grid-cols-1 lg:grid-cols-2 gap-5 pb-10 org-cont pt-10 ytd-cont",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "duration-300 cursor-pointer pt-[80px] bg-[url('/testiA.jpeg')] bg-cover h-[450px]",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "p-10 text-[#d29240] text-2xl overflow-hidden bg-[#edfae9]",
                        children: [
                            "Start your Ayurvedic Journey! Book a complimentary video consultation customised to your skin & hair concerns in the comfort & safety of your home.",
                            " "
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "duration-300 cursor-pointer flex flex-col justify-center items-center overflow-hidden",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                            width: "560",
                            height: "315",
                            src: "https://www.youtube.com/embed/CNloqpXwyMg?si=HrQcXztAKXvImwK_",
                            title: "YouTube video player",
                            frameBorder: "0",
                            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
                            allowFullScreen: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "flex items-center w-ful h-12 text-center text-2xl",
                            children: "Virtual Consultation"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "custom-btn uppercase border pt-[.5em] pb-[.5em] pl-[3em] pr-[3em] border-[#d29240] block text-[#d29240]",
                            children: "Book your free session"
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 1828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ testiData),
/* harmony export */   "T": () => (/* binding */ banners)
/* harmony export */ });
const testiData = [
    {
        name: "Anna sharma",
        designation: "Actress",
        testi: '"oh my god, I genuinely love your products! My hair is kind of damaged in the ends because i colored it and the cold pressed neem oil has changed my hair. It’s so so soft and my ends look so healthy! This beats any hair treatment I’ve done till now. <br /> <br /> Sending the Avani family lots of best wishes x"'
    },
    {
        name: "Rajiya rijal",
        testi: '"Hello, I swear by your Jojoba oil for my skin. I increase the quantity for winter and decrease for summers. Thank you for making it accessible \uD83E\uDD70"'
    },
    {
        name: "Grishma S. <br /> Rajbhandari",
        testi: '"Im liking the hair oil alot though. Makes my hair super soft \uD83D\uDE0A"'
    },
    {
        name: "Genelia",
        testi: '"You guys are doing great I love all the products"'
    },
    {
        name: "Hayyat timisina",
        testi: '"The BEST thing I ever purchased is Rosemary & jojoba Mero hair growth herisyo bhane you will be shocked too. I love it"'
    },
    {
        name: "Sofia",
        testi: '"I have really enjoyed using your rosehip oil."'
    },
    {
        name: "Anuradha",
        testi: '"The lipbalm smells really good and is really nice Thankyou \uD83D\uDE0C"'
    }
];
const banners = [
    {
        header: "Avani Nepal",
        desc: "Avani Nepal is an ethical skincare, haircare and wellness brand that scientifically formulates all natural products in Nepal, using potent Himalayan medicinal herbs, traditional",
        btn: "Shop Now",
        link: "/products?search=&sort=&category=",
        style: {
            height: "100%",
            width: "100%",
            objectFit: "cover"
        },
        img: "/banner/b1.jpeg"
    },
    {
        header: "Avani Nepal",
        desc: "Avani Nepal is an ethical skincare, haircare and wellness brand that scientifically formulates all natural products in Nepal, using potent Himalayan medicinal herbs, traditional",
        btn: "Shop Now",
        link: "/products?search=&sort=&category=",
        style: {
            height: "100%",
            width: "100%",
            objectFit: "cover"
        },
        img: "/banner/b2.jpeg"
    },
    {
        header: "Avani Nepal",
        desc: "Avani Nepal is an ethical skincare, haircare and wellness brand that scientifically formulates all natural products in Nepal, using potent Himalayan medicinal herbs, traditional",
        btn: "Shop Now",
        link: "/products?search=&sort=&category=",
        style: {
            height: "100%",
            width: "100%",
            objectFit: "cover"
        },
        img: "/banner/b3.jpeg"
    },
    {
        header: "Avani Nepal",
        desc: "Avani Nepal is an ethical skincare, haircare and wellness brand that scientifically formulates all natural products in Nepal, using potent Himalayan medicinal herbs, traditional",
        btn: "Shop Now",
        link: "/products?search=&sort=&category=",
        img: "/banner/show1.jpg"
    }, 
];


/***/ }),

/***/ 3678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7532);
/* harmony import */ var flowbite_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(flowbite_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_TopHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(922);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7673);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5789);
/* harmony import */ var _components_ImageSlider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7736);
/* harmony import */ var _components_CustomSlider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5337);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_ProductCard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3258);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _public_show3_webp__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1122);
/* harmony import */ var _public_show5_webp__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(746);
/* harmony import */ var _public_show6_webp__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9263);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_Container__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2369);
/* harmony import */ var _components_BlogCard__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3162);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1838);
/* harmony import */ var _components_Testimonial__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6986);
/* harmony import */ var _components_Organic__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6853);
/* harmony import */ var _components_Promise__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9741);
/* harmony import */ var _components_IgSection__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(7877);
/* harmony import */ var _components_YtdSection__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(3890);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_TopHeader__WEBPACK_IMPORTED_MODULE_3__, _components_Layout__WEBPACK_IMPORTED_MODULE_5__, _components_ProductCard__WEBPACK_IMPORTED_MODULE_9__, _components_BlogCard__WEBPACK_IMPORTED_MODULE_17__]);
([_components_TopHeader__WEBPACK_IMPORTED_MODULE_3__, _components_Layout__WEBPACK_IMPORTED_MODULE_5__, _components_ProductCard__WEBPACK_IMPORTED_MODULE_9__, _components_BlogCard__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















// import CategoryCard from "../components/Categorycard";







const index = ({ banners , newLaunches , featuredProducts , bestSeller , discountProduct , trendingProduct , skinConcern , hairConcern , blogs , aboutUsData ,  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        console.log("========= hya dekhi ========");
        console.log(bestSeller);
        console.log("========= hya samma ========");
    }, []);
    console.log("featuredProducts", featuredProducts);
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    initialSlide: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true
                }
            }, 
        ]
    };
    const Blogsettings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                Blogsettings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    infinite: true
                }
            },
            {
                breakpoint: 600,
                Blogsettings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    initialSlide: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 480,
                Blogsettings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true
                }
            }, 
        ]
    };
    // console.log(
    //   "newLaunches",
    //   bestSeller.sort((a, b) => parseInt(b.bestSeller) - parseInt(a.bestSeller))
    // );
    console.log("skinConcern", banners.filter((value)=>value.type === 1)[0]);
    const firstBanner = banners.filter((value)=>value.type === 1)[0];
    // console.log("firstBanner", firstBanner);
    const secondBanner = banners.filter((value)=>value.type === 2)[0];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        aboutUsData: aboutUsData,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CustomSlider__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Container__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-7",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex md:justify-center items-center relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-center text-2xl mb-3",
                                    children: "New Launches"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    href: "/products?search=&sort=&category=",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "absolute right-0",
                                        children: "View More.."
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_8___default()), {
                                ...settings,
                                children: newLaunches && newLaunches.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, index))
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/banner2.png",
                    alt: "..."
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
            firstBanner && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-7",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: " w-full h-48 md:h-96 overflow-hidden bg-gray-200 relative",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                        href: `/product/${firstBanner.product.slug}?main_category=${firstBanner.product.main_category}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_10___default()), {
                                alt: "Mountains",
                                src: `${_config__WEBPACK_IMPORTED_MODULE_18__/* .baseUrl */ .FH}/${firstBanner.image}`,
                                priority: true,
                                objectFit: "cover",
                                layout: "fill"
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Container__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-7",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex md:justify-center items-center relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-center text-2xl mb-3",
                                    children: "Best Sellers"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    href: "/products?search=&sort=bestSeller&category=",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "absolute right-0",
                                        children: "View More.."
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: bestSeller.length > 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_8___default()), {
                                ...settings,
                                children: bestSeller.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "p" + index))
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-4 gap-1",
                                children: bestSeller.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "c" + index))
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/banner3.png",
                    alt: "..."
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Container__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-7",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex md:justify-center items-center relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-center text-2xl mb-3",
                                    children: "Featured Products"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    href: "/products?search=&sort=bestSeller&category=",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "absolute right-0",
                                        children: "View More.."
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: featuredProducts.length > 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_8___default()), {
                                ...settings,
                                children: featuredProducts.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "f" + index))
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-1 sm:grid-cols-3 md:grid-cols-4 gap-1",
                                children: featuredProducts.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "f" + index))
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/banner4.png",
                    alt: "..."
                })
            }),
            secondBanner && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-20",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: " w-full h-48 md:h-96 overflow-hidden bg-gray-200 relative",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                        href: `/product/${secondBanner.product && secondBanner.product.slug}?main_category=${secondBanner.product && secondBanner.product.main_category}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_10___default()), {
                                alt: "Mountains",
                                src: `${_config__WEBPACK_IMPORTED_MODULE_18__/* .baseUrl */ .FH}/${secondBanner.image}`,
                                priority: true,
                                objectFit: "cover",
                                layout: "fill"
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Container__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-7",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex md:justify-center items-center relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-center text-2xl mb-3",
                                    children: "Trending Now"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    href: "/products?search=&sort=trending&category=",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "absolute right-0",
                                        children: "View More.."
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: trendingProduct.length > 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_8___default()), {
                                ...settings,
                                children: trendingProduct.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "t" + index))
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-4 gap-1",
                                children: trendingProduct.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "t" + index))
                            })
                        })
                    ]
                })
            }),
            discountProduct.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Container__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-7",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex md:justify-center items-center relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-center text-2xl mb-3",
                                    children: "Save On Sets"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    href: "/products?search=&sort=discount&category=",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "absolute right-0",
                                        children: "View More.."
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: discountProduct.length > 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_8___default()), {
                                ...settings,
                                children: discountProduct.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "d" + index))
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-1",
                                children: discountProduct.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            value: value
                                        })
                                    }, "d" + index))
                            })
                        })
                    ]
                })
            }) : null,
            blogs.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Container__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-7",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex md:justify-center items-center relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-center text-2xl mb-3",
                                    children: "From Our Blog"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    href: "/blogs",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "absolute right-0",
                                        children: "View More.."
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: blogs.length > 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_8___default()), {
                                ...settings,
                                children: blogs.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BlogCard__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                        value: value
                                    }, "b" + index))
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8",
                                children: blogs.map((value, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_BlogCard__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                        value: value
                                    }, "b" + index))
                            })
                        })
                    ]
                })
            }) : null,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Organic__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Testimonial__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_YtdSection__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_IgSection__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {})
        ]
    });
};
async function getServerSideProps() {
    const banner = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/banner`);
    const newLaunches = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/product/all`);
    const featuredProducts = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/product/featured`);
    const bestSeller = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/product/filter/product?bestSeller=0`);
    const discountProduct = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/product/filter/product?discount=10`);
    const trendingProduct = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/product/filter/product?trending=0`);
    const skinConcern = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/childCategoryImage?main_category=skin&sub_category=shop_by_concerns`);
    const hairConcern = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/childCategoryImage?main_category=hair&sub_category=shop_by_concerns`);
    const blogs = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/blog/published`);
    const aboutUs = await axios__WEBPACK_IMPORTED_MODULE_15___default().get(`${_config__WEBPACK_IMPORTED_MODULE_18__/* .API */ .bl}/aboutus`);
    return {
        props: {
            banners: banner.data,
            newLaunches: newLaunches.data,
            featuredProducts: featuredProducts.data,
            bestSeller: bestSeller.data.sort((a, b)=>parseInt(b.bestSeller) - parseInt(a.bestSeller)),
            discountProduct: discountProduct.data.sort((a, b)=>parseInt(b.price_discount) - parseInt(a.price_discount)),
            trendingProduct: trendingProduct.data.sort((a, b)=>parseInt(b.trending) - parseInt(a.trending)),
            skinConcern: skinConcern.data,
            hairConcern: hairConcern.data,
            blogs: blogs.data,
            aboutUsData: aboutUs.data[0]
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 7532:
/***/ ((module) => {

module.exports = require("flowbite-react");

/***/ }),

/***/ 4558:
/***/ ((module) => {

module.exports = require("next/config");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 7840:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9646:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,61,789,20,47,353,266,258,162], () => (__webpack_exec__(3678)));
module.exports = __webpack_exports__;

})();